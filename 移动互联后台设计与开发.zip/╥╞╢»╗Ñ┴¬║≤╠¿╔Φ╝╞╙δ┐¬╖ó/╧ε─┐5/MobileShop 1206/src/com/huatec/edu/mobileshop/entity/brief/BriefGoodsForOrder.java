package com.huatec.edu.mobileshop.entity.brief;

public class BriefGoodsForOrder {
	private String name;//名称
	private Double price;//销售价
	private Double mktprice;//市场价
	private String small;//小图
	private String thumbnail;//缩略图
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getMktprice() {
		return mktprice;
	}
	public void setMktprice(Double mktprice) {
		this.mktprice = mktprice;
	}
	public String getSmall() {
		return small;
	}
	public void setSmall(String small) {
		this.small = small;
	}
	public String getThumbnail() {
		return thumbnail;
	}
	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}
	public String toString() {
		return "BriefGoodsForOrder [name=" + name + ", price=" + price + ", mktprice=" + mktprice + ", small=" + small
				+ ", thumbnail=" + thumbnail + "]";
	}
}
