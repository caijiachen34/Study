package com.huatec.edu.mobileshop.dao;

import java.util.List;

import com.huatec.edu.mobileshop.entity.Ship;

public interface ShipDao {
	public int save(Ship ship);
	public List<Ship> findAll();
	public int deleteById(int ship_id);
	public Ship findById(int ship_id);
	public int dynamicUpdate(Ship ship);
	public Ship dynamicFind(Ship ship);
}
