package com.huatec.edu.mobileshop.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class Role implements Serializable {
	private Integer role_id;
	private String name;
	private String description;
	private Timestamp creatime;//创建时间
	private Timestamp modifytime;//修改时间
	
	public Integer getRole_id() {
		return role_id;
	}
	public void setRole_id(Integer role_id) {
		this.role_id = role_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Timestamp getCreatime() {
		return creatime;
	}
	public void setCreatime(Timestamp creatime) {
		this.creatime = creatime;
	}
	public Timestamp getModifytime() {
		return modifytime;
	}
	public void setModifytime(Timestamp modifytime) {
		this.modifytime = modifytime;
	}
	
	public String toString() {
		return "Role [role_id=" + role_id + ", name=" + name + ", description=" + description + ", creatime=" + creatime
				+ ", modifytime=" + modifytime + "]";
	}
}
