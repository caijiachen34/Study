package com.huatec.edu.mobileshop.entity.brief;

import java.io.Serializable;

public class BriefGoodsType implements Serializable {
	private Integer type_id;//类型编号
	private String name;//类型名称
	private String params;//参数
	
	public Integer getType_id() {
		return type_id;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}
	public String toString() {
		return "BriefGoodsType [type_id=" + type_id + ", name=" + name + ", params=" + params + "]";
	}
}
