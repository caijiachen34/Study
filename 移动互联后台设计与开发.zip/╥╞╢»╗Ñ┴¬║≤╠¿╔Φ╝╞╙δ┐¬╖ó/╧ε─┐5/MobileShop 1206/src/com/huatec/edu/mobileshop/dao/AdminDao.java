package com.huatec.edu.mobileshop.dao;

import java.util.List;
import java.util.Map;

import com.huatec.edu.mobileshop.entity.Admin;

public interface AdminDao {
	public int save(Admin admin);
	public List<Admin> findAll();
	public int deleteById(int admin_id);
	public Admin findById(int admin_id);
	public int dynamicUpdate(Admin admin);
	public Admin dynamicFind(Map map);
	public List<Admin> findUnion();
}
