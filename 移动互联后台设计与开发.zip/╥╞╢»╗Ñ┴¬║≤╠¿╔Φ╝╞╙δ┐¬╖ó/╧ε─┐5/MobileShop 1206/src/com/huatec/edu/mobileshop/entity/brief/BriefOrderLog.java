package com.huatec.edu.mobileshop.entity.brief;

import java.io.Serializable;
import java.sql.Timestamp;

public class BriefOrderLog implements Serializable {
	private Integer status;
	private Timestamp time;
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Timestamp getTime() {
		return time;
	}
	public void setTime(Timestamp time) {
		this.time = time;
	}
	public String toString() {
		return "BriefOrderLog [status=" + status + ", time=" + time + "]";
	}
	
}
