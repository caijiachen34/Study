package com.huatec.edu.mobileshop.dao;

import java.util.List;

import com.huatec.edu.mobileshop.entity.Logi;

public interface LogiDao {
	public int save(Logi logi);
	public List<Logi> findAll();
	public int deleteById(int logi_id);
	public Logi findById(int logi_id);
	public int dynamicUpdate(Logi logi);
}
