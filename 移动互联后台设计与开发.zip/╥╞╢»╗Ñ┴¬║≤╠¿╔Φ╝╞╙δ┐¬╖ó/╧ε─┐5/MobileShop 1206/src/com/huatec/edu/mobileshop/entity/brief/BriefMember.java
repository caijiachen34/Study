package com.huatec.edu.mobileshop.entity.brief;

import java.io.Serializable;

public class BriefMember implements Serializable{
	private Integer member_id;//编号
	private String uname;//会员名
	
	public Integer getMember_id() {
		return member_id;
	}
	public void setMember_id(Integer member_id) {
		this.member_id = member_id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String toString() {
		return "BriefMember [member_id=" + member_id + ", uname=" + uname + "]";
	}
}
