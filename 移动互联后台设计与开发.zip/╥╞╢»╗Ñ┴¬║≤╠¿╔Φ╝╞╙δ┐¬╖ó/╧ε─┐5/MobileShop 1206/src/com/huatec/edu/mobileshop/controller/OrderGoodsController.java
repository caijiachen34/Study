package com.huatec.edu.mobileshop.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.huatec.edu.mobileshop.service.OrderGoodsService;
import com.huatec.edu.mobileshop.util.Result;

@Controller
@RequestMapping("/order_goods")
public class OrderGoodsController {
	@Resource
	private OrderGoodsService orderGoodsService;
	
	/*@RequestMapping(value="/member/{memberId}",method=RequestMethod.GET)
	@ResponseBody
	public Result loadByMemberId(@PathVariable("memberId") int memberId){
		Result result=orderGoodsService.loadUnionByMemberId(memberId);
		return result;
	}*/
}
