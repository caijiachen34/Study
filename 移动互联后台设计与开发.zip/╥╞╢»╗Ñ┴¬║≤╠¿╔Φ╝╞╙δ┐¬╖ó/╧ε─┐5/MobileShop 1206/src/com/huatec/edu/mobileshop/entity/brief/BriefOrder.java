package com.huatec.edu.mobileshop.entity.brief;

import java.io.Serializable;

public class BriefOrder implements Serializable {
	private Integer order_id;
	private String sn;
	//关联属性
	private BriefOrderLog bol;
	
	public Integer getOrder_id() {
		return order_id;
	}
	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	
	public BriefOrderLog getBol() {
		return bol;
	}
	public void setBol(BriefOrderLog bol) {
		this.bol = bol;
	}
	public String toString() {
		return "BriefOrder [order_id=" + order_id + ", sn=" + sn + ", bol=" + bol + "]";
	}
	
}
