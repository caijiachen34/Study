package com.huatec.edu.mobileshop.entity;

import java.io.Serializable;
import java.sql.Timestamp;
//商品类型
public class GoodsType implements Serializable {
	private Integer type_id;//类型编号
	private String name;//类型名称
	private String params;//参数
	private Integer disabled;//是否可用，0：可用，1：不可用
	private Integer is_physical;//是否是实体商品，0：是，1：不是
	private Timestamp creatime;//创建时间
	private Timestamp modifytime;//修改时间
	
	//get、set方法
	public Integer getType_id() {
		return type_id;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}
	public Integer getDisabled() {
		return disabled;
	}
	public void setDisabled(Integer disabled) {
		this.disabled = disabled;
	}
	public Integer getIs_physical() {
		return is_physical;
	}
	public void setIs_physical(Integer is_physical) {
		this.is_physical = is_physical;
	}
	public Timestamp getCreatime() {
		return creatime;
	}
	public void setCreatime(Timestamp creatime) {
		this.creatime = creatime;
	}
	public Timestamp getModifytime() {
		return modifytime;
	}
	public void setModifytime(Timestamp modifytime) {
		this.modifytime = modifytime;
	}
	//toStirng方法
	public String toString() {
		return "GoodsType [type_id=" + type_id + ", name=" + name + ", params=" + params + ", disabled=" + disabled
				+ ", is_physical=" + is_physical + ", creatime=" + creatime + ", modifytime=" + modifytime + "]";
	}
	
}
