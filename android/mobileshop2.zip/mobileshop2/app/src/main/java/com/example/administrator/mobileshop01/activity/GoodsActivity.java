package com.example.administrator.mobileshop01.activity;

import android.os.Bundle;

import com.example.administrator.mobileshop01.R;


public class GoodsActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);

    }

}
