package com.example.administrator.mobileshop01.common;


/**
 * 常量数据类放检查使用的数据，如url
 */
public class Constants {
    public static String BASE_URL="http://112.74.91.93:8080/MobileShop/";

    public static int AD_TIME_SECOND=3000;

    public static int SPAN_COUNT=3;

}
