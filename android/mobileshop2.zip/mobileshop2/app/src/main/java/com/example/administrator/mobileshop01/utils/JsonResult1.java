package com.example.administrator.mobileshop01.utils;

public class JsonResult1{

}
