package com.example.administrator.mobileshop01.adapter;

import android.view.View;

import com.example.administrator.mobileshop01.entity.CategoryEntity;

public interface OnRecyclerViewItemClickListener {
    void onItemClick(View view, CategoryEntity data);
}
