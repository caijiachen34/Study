package com.southwind.layui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LayuiApplicationTests {

    @Test
    void contextLoads() {
    }

}
