package com.southwind.layui.entity;

import lombok.Data;

@Data
public class ProductCategory {
    private Integer id;
    private String name;
}
