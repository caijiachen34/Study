package com.southwind.layui.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.southwind.layui.entity.ProductCategory;

public interface ProductCategoryMapper extends BaseMapper<ProductCategory> {
}
