package com.southwind.layui.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PieVO {
    private Integer value;
    private String name;
}
