-- 删除头像关联表，将头像信息存入 sys_user 表，执行前先执行 字段调整. --
DROP TABLE user_avatar