1.将类路径  ${package}.${moduleName} 改为了：${package}.${tableName}
2.增加了增删改查逻辑


计划：
1.个性化定制


联系：

qq：64738479