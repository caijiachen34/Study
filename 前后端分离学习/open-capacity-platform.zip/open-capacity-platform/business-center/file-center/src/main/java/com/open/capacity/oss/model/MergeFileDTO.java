package com.open.capacity.oss.model;

import lombok.Data;

@Data
public class MergeFileDTO {

   private String guid;
   private String fileName;

}
