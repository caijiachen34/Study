package com.ccit.util;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.ccit.entity.AdUser;
import com.sun.org.apache.bcel.internal.generic.RETURN;

public class DBUtilsDao {
	//查询所有，返回List集合
	public List findAll() throws SQLException{
		//创建QueryRunner对象
		QueryRunner runner = new QueryRunner(C3p0Utils.getDataSource());
		//写SQL语句
		String sql = "select * from ad_account";
		//调用方法
		List list = (List) runner.query(sql, new BeanListHandler(AdUser.class));
		
		return list;

}
	//查询单个，返回对象
	public AdUser find(int id) throws SQLException{
		//创建QueryRunner对象
		QueryRunner runner = new QueryRunner(C3p0Utils.getDataSource());
		//写SQL语句
		String sql = "select * from ad_account where ademail=?";
		//调用方法
		AdUser adUser = (AdUser) runner.query(sql, new BeanListHandler(AdUser.class),new Object[] {id});
		return adUser;
		
	}
	//添加管理员的操作
	public Boolean insert(AdUser aduser) throws SQLException{
		//创建QueryRunner对象
		QueryRunner runner = new QueryRunner(C3p0Utils.getDataSource());
		//写SQL语句
		String sql = "insert into ad_account(adname,ademail,adpassword) values (?,?,?)";
		//调用方法
		int num = runner.update(sql,new Object[] {aduser.getAdname(),aduser.getAdemail(),aduser.getAdpassword() });
				if(num > 0) 
				return true;
			return false;
	}
	//修改管理员的操作
	public Boolean update(AdUser aduser) throws SQLException{
		//创建QueryRunner对象
		QueryRunner runner = new QueryRunner(C3p0Utils.getDataSource());
		//写SQL语句
		String sql = "update ad_account set adname=?,adpassword=? where ademail=?";
		//调用方法
		int num = runner.update(sql,new Object[] {aduser.getAdname(),aduser.getAdpassword() });
		if(num > 0)
			return true;
		return false;
	}
	//删除管理员的操作
	public Boolean delete(String ademail) throws SQLException{
		//创建QueryRunner对象
		QueryRunner runner = new QueryRunner(C3p0Utils.getDataSource());
		//写SQL语句
		String sql = "delete from ad_account where id=?";
		//调用方法
		int num = runner.update(sql,ademail);
		if(num > 0)
			return true;
		return false;
	}
}