package com.ccit.model;

public class AdUserBean {

	private String adname;//定义管理员名字
	private String ademail;//定义管理员邮箱
	private String adpassword;//定义管理员密码
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getAdemail() {
		return ademail;
	}
	public void setAdemail(String ademail) {
		this.ademail = ademail;
	}
	public String getAdpassword() {
		return adpassword;
	}
	public void setAdpassword(String adpassword) {
		this.adpassword = adpassword;
	}
	
	
}
