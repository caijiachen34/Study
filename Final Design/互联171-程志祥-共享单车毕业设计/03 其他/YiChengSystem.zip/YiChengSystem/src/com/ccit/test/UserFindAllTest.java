package com.ccit.test;

import java.util.ArrayList;
import com.ccit.entity.User;
import com.ccit.mapper.UserMapper;

public class UserFindAllTest {
	
	public static void main(String[] args) {
		UserMapper userMaperr = new UserMapper();
		ArrayList<User> list = userMaperr.findAll();
		
		for(int i = 0; i < list.size(); i++) {
			
			System.out.println("第" + (i + 1) + "条数据的设备名为:" + list.get(i).getSn());
		}
		
	}

}
