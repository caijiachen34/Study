package com.ccit.test;

import com.ccit.entity.User;
import com.ccit.mapper.UserMapper;

public class UserUpdateTest {

	public static void main(String[] args) {
		//修改User对象的数据
		UserMapper userMapper = new UserMapper();
		User user = new User();
		//该处外键修改失败
//		user.setId(3);
//		user.setSn("706");
//		user.setPhone("17607022502");
//		boolean b = userMapper.update(user);
//		System.out.println(b);

	}

}
