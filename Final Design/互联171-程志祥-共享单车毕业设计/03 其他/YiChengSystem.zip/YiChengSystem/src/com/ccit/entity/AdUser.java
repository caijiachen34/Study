package com.ccit.entity;

public class AdUser {
	
	private String adname;
	private String ademail;
	private String adpassword;
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getAdemail() {
		return ademail;
	}
	public void setAdemail(String ademail) {
		this.ademail = ademail;
	}
	public String getAdpassword() {
		return adpassword;
	}
	public void setAdpassword(String adpassword) {
		this.adpassword = adpassword;
	}
	
	

}
