package com.ccit.test;

import java.sql.SQLException;

import com.ccit.entity.AdUser;
import com.ccit.util.DBUtilsDao;

public class AdUserDaoTest {
	private static DBUtilsDao dao = new DBUtilsDao();
	public static void testInsert() throws SQLException{
		AdUser aduser = new AdUser();
		aduser.setAdname("zhanghao");
		aduser.setAdemail("88888888@qq.com");
		aduser.setAdpassword("777777");
		boolean b = dao.insert(aduser);
		System.out.println(b);
	}
	public static void main(String[] args) throws SQLException{
		testInsert();
		
	}

}
