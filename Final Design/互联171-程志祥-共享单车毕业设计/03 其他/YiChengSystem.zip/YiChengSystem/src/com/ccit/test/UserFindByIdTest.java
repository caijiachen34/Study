package com.ccit.test;

import com.ccit.entity.User;
import com.ccit.mapper.UserMapper;

public class UserFindByIdTest {

	public static void main(String[] args) {
		UserMapper userMapper = new UserMapper();
		User user = userMapper.find(1);
		System.out.println("id为1的User对象的手机号为:" + user.getPhone());
		

	}

}
