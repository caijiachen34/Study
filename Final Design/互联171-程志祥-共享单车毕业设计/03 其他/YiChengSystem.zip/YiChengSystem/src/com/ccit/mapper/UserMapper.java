package com.ccit.mapper;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.ccit.entity.User;
import com.ccit.util.JDBCUtils;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class UserMapper {
	
	//添加用户
	public boolean insert(User user) {
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			//获得数据库连接
			conn = JDBCUtils.getConnection();
			//获得Statement对象
			stmt = (Statement) conn.createStatement();
			//发送SQL语句
			String sql = "INSERT INTO t_user(id,sn,phone)"+
			"VALUES("
					+ user.getId()
					+",'"
					+ user.getSn()
					+"','"
					+ user.getPhone()+"')";
			
			int num = stmt.executeUpdate(sql);
			if(num > 0) {
				return true;
			}
			return false;
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return false;
	}
	
	//查询所有的User对象
	public 	ArrayList<User> findAll() {
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		ArrayList<User> list = new ArrayList<User>();
		try {
			//获取数据库连接
			conn = JDBCUtils.getConnection();
			//获得Statement对象
			stmt = (Statement) conn.createStatement();
			//发送SQL语句
			String sql = "SELECT * FROM t_user";
			rs = stmt.executeQuery(sql);
			//处理结果集
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setSn(rs.getString("sn"));
				user.setPhone(rs.getString("phone"));
				list.add(user);
				
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return null;
	}
	
	//根据id查找特定的user
	public User find(int id) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			//获得数据库连接
			conn = JDBCUtils.getConnection();			
			//获得Statement对象
			stmt = (Statement) conn.createStatement();
			//发送SQL语句
			String sql = "SELECT * FROM t_user WHERE id="+id;
			rs = stmt.executeQuery(sql);
			//处理结果集
			while(rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setSn(rs.getString("sn"));
				user.setPhone(rs.getString("phone"));
				
				return user;				
				
			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return null;
	}
	//删除用户
	public boolean delete(int id) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			//获得数据库连接
			conn = JDBCUtils.getConnection();			
			//获得Statement对象
			stmt = (Statement) conn.createStatement();
			//发送SQL语句
			String sql = "DELETE FROM t_user WHERE id="+id;
			int num = stmt.executeUpdate(sql);
			if(num > 0) {
				return true;
			}
			return false;
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return false;
	}
	
	//修改用户
	public boolean update(User user) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			//获得数据库连接
			conn = JDBCUtils.getConnection();			
			//获得Statement对象
			stmt = (Statement) conn.createStatement();
			//发送SQL语句
			String sql = "UPDATE t_user set id='"
						+ user.getId()
						+ "',sn='" + user.getSn()
						+ "',phone=" + user.getPhone();
			int num = stmt.executeUpdate(sql);
			if(num > 0) {
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
		return false;
	}
	
	
}
