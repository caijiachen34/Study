package com.ccit.test;

import com.ccit.entity.User;
import com.ccit.mapper.UserMapper;

public class UserAddTest {

	public static void main(String[] args) {
		//向t_user中插入一个用户信息
		UserMapper um = new UserMapper();
		User user = new User();
		user.setId(1);
		user.setSn("704");
		user.setPhone("15151966201");
		boolean b = um.insert(user);
		System.out.println(b);
		
		
	}

}
