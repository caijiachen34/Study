package com.ccit.dao;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class IncreaseDao {

	public static void main(String[] args) throws SQLException{
		Connection conn = null;
		PreparedStatement prestmt = null;
		try {
			//注册数据库的驱动
			Class.forName("com.mysql.jdbc.Driver");
			//通过DriverManager获取数据库连接
			String url = "jdbc:mysql://localhost:3306/yicheng";
			String username = "root";
			String password = "123456";
			conn = (Connection) DriverManager.getConnection(url,username,password);
			String sql = "INSERT INTO ad_account(adName,adEmail,adPassword)"+"VALUES(?,?,?)";
			//创建执行SQL语句的PreparedStatement
			prestmt = (PreparedStatement) conn.clientPrepareStatement(sql);
			//为SQL语句中的参数赋值
			prestmt.setString(1, "Myss");
			prestmt.setString(2, "665626@qq.com");
			prestmt.setString(3, "559459");
			//执行SQL
			prestmt.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(prestmt!=null) {
				try {
					prestmt.close();
				}catch(SQLException e) {
					e.printStackTrace();
					
				}
				prestmt = null;
			}
			if(conn!=null) {
				try {
					conn.close();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}
				conn = null;
			}
			
		}
		

	}

}
