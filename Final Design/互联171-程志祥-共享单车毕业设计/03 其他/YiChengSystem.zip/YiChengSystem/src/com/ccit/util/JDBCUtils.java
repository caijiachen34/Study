package com.ccit.util;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class JDBCUtils {
	
	public static Connection getConnection() throws SQLException,ClassNotFoundException{
		//注册数据库的驱动
		Class.forName("com.mysql.jdbc.Driver");
		//通过DriverManager获取数据库连接
		String url = "jdbc:mysql://localhost:3306/yicheng";
		String username = "root";
		String password = "123456";
		Connection conn = (Connection) DriverManager.getConnection(url,username,password);
		return conn;
		
	}
	//关闭数据库连接，释放资源
	public static void release(ResultSet rs, Statement pstmt, java.sql.Connection conn) {
		if(pstmt!=null) {
			try {
				pstmt.close();
			}catch (SQLException e) {
				
				e.printStackTrace();
			}
			pstmt = null;
			
			if(conn!=null) {
				try {
					conn.close();
				}catch (SQLException e) {
					e.printStackTrace();
				}
				conn = null;
			}
			if(rs != null) {
				try {
					rs.close();
				}catch (SQLException e) {
					e.printStackTrace();
					// TODO: handle exception
				}
				rs = null;
			}
			release(rs,pstmt,conn);
		
	}
	}
}