package com.ccit.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class C3p0ConnectDao {
	public static DataSource ds = null;
	//初始化C0P0数据源
	static {
		//使用c3p0-config.xml配置文件中的named-config节点中name属性的值
		ComboPooledDataSource cpds = new ComboPooledDataSource("itcast");
		ds = cpds;
		
	}
	public static void main(String[] args) throws SQLException{
		//获取数据库连接对象
		System.out.println(ds.getConnection());
	}

}
