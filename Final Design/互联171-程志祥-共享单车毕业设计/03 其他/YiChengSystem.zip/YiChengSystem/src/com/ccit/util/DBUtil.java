package com.ccit.util;

import java.util.HashMap;

import com.ccit.model.AdUserBean;

public class DBUtil {
	private static DBUtil instance =  new DBUtil();
	//定义aduser集合，用于模拟数据库	
	private HashMap<String, AdUserBean>  adusers = new  HashMap<String, AdUserBean>();
	private DBUtil(){
		//向数据库（ad_account）中存入两条数据
		AdUserBean aduser1 = new AdUserBean();
		aduser1.setAdname("Jack");
		aduser1.setAdemail("12345645@qq.com");
		aduser1.setAdpassword("888888");
		adusers.put("Jack", aduser1);
		AdUserBean aduser2 = new AdUserBean();
		aduser2.setAdname("Rose");
		aduser2.setAdemail("55648784@qq.com");
		aduser2.setAdpassword("897895");
		adusers.put("Rose", aduser2);
		
	}
	public static DBUtil getInstance() {
		return instance;
	}
	//获取数据库（ad_account）中的数据
	public AdUserBean getAdUser(String adUserName) {
		AdUserBean aduserB = adusers.get(adUserName);
		return aduserB;
	}
	//向数据库中插入数据
	public boolean insertAdUser(AdUserBean aduser) {
		if(aduser == null)
		{
		return false;
		}
		String adUsername = aduser.getAdname();
		if(adusers.get(adUsername) != null) {
			return false;
		}
		adusers.put(adUsername, aduser);
		return true;
	}
}
