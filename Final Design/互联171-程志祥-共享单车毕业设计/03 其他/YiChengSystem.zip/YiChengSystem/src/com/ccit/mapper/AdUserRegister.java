package com.ccit.mapper;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ccit.entity.AdUser;
import com.ccit.model.AdUserBean;
import com.ccit.model.RegisterFromBean;
import com.ccit.util.DBUtil;
import com.ccit.util.DBUtilsDao;


@WebServlet("/AdUserRegister")
public class AdUserRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);			
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Content-type", "text/html;charset=UTF-8");
		response.setCharacterEncoding("utf-8");
		//获取管理员注册是提交的参数信息
		String adname = request.getParameter("adname");
		String ademail = request.getParameter("ademail");
		String adpassword = request.getParameter("adpassword");
		//将获取的参数封装到管理员账户类中
		RegisterFromBean formBean = new RegisterFromBean();
		formBean.setAdname(adname);
		formBean.setAdemail(ademail);
		formBean.setAdpassword(adpassword);
		//检验格式
		//TODO
		AdUserBean aduserBean = new AdUserBean();
		aduserBean.setAdname(adname);
		aduserBean.setAdemail(ademail);
		aduserBean.setAdpassword(adpassword);
		//调用DBUtil的insertUser()方法执行添加操作，并返回一个boolean类型的标志
		boolean b = DBUtil.getInstance().insertAdUser(aduserBean);
		//判断
		if(!b) {
			request.setAttribute("DBMes", "你注册的用户已经存在");
			request.setAttribute("fromBean", formBean);
			request.getRequestDispatcher("/register.jsp")
			.forward(request, response);
			return;
		}
		response.getWriter().print("注册成功，3秒后自动跳转");
		//将成功注册的管理员信息添加到Session中
		request.getSession().setAttribute("aduserBean", aduserBean);
		//注册成功，三秒跳转
		response.setHeader("refresh", "3;url=login.jsp");
		
				}

}
